Gameduino is the amazing open source FPGA project created by James Bowman.

For more information and documentation visit:
http://excamera.com/sphinx/gameduino/

The project is open source and the original source code can be downloaded from here:
http://excamera.com/sphinx/gameduino/making.html
http://excamera.com/files/gameduino/verilog/